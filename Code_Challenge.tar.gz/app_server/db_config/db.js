module.exports = {
    url: 'mongodb://localhost/Referer'
}
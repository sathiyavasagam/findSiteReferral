# findSiteReferral

#Purpose:

To store the referral website information.

# Install Setup:

Node- 6.10.1+ and mongodb-3.2.17 +

# Steps to run:

npm install
bower install.
Then Run- node server.js




